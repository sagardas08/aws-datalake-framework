class DependencyError(Exception):
    pass


class NamedTransformNotFound(Exception):
    pass


class TransformNotFound(Exception):
    pass
